#include<iostream>
using namespace std;

class Employee
{
	double salary;
	int noOfHours;
public:
	Employee() {}
	void getinfo()
	{
		cout << "enter the salary of employee: ";
		cin >> salary;
		cout << "enter the nober of hours: ";
		cin >> noOfHours;
	}
	void AddSal()
	{
		if (salary < 500)
			salary += 10;
	}
	void AddWork()
	{
		if (noOfHours > 6)
			salary += 5;
	}
	void DisplaySalary()
	{
		cout << salary;
	}
};

int main()
{
	int no;
	cout << "Enter the number of employees: ";
	cin >> no;
	Employee* emp=new Employee[no];
	for (int i = 0; i < no ; i++)
	{
		emp[i].getinfo();
		emp[i].AddSal();
		emp[i].AddWork();
	}
	for (int i = 0; i < no; i++)
	{
		cout << "\nThe final salary of employee "<< i +1 <<" is:";
		emp[i].DisplaySalary();
	}
}