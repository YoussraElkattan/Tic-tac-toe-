//Q1

#include <iostream>
#include <string>
using namespace std;

class student {
public:
    string name;
    string phone_no;
    string address;
    int roll_no;
};

int main() {
    student no1;
    no1.name = "Sam";
    no1.phone_no = "24568277";
    no1.address = "California-US";
    no1.roll_no = 1;
    student no2;
    no2.name = "John";
    no2.phone_no = "56371837";
    no2.address = "London-UK";
    no2.roll_no = 2;

    cout << "Student 1" << endl;
    cout << "Name: " << no1.name << endl;
    cout << "roll: " << no1.roll_no << endl;
    cout << "Phone-no: : " << no1.phone_no << endl;
    cout << "Address: " << no1.address << endl;
    cout << "Student 2" << endl;
    cout << "roll: " << no2.roll_no << endl;
    cout << "Name: " << no2.name << endl;
    cout << "Phone-no: : " << no2.phone_no << endl;
    cout << "Address: " << no2.address << endl;

}
//Q2
/*
#include <iostream>
#include <string>
#include <cmath>
using namespace std;

class Triangle
{
public:
    int s1,s2,s3;
    Triangle(int a,int b,int c)
    {
        s1 = a;
        s2 = b;
        s3 = c;
    }
    void print_area()
    {
        double s = (s1+s2+s3)/2.0;
        cout << "Area is: "<< s << endl;
        cout << "Perimeter is: " << (s1+s2+s3) << endl;
    }
};

int main()
{
    Triangle t(3,4,5);
    t.print_area();
    return 0;
}
//Q3

#include <iostream>
using namespace std;
class Average{
    public:
    static float calcAverage(float a, float b, float c){
        return (a + b + c) / 3;
    }
};


int main(){
    cout<<"Enter three numbers: ";
    float a, b, c;
    cin>>a;
    cin>>b;
    cin>>c;
    cout<<"The average is: "<<Average::calcAverage(a,b,c)<<endl;
    return 0;
}
//Q4
#include<iostream>
using namespace std;

class Employee
{
	double salary;
	int no_of_hours;
public:
	Employee() {}
	void getinfo()
	{
		cout << "Please, enter the salary of employee: ";
		cin >> salary;
		cout << "Please, enter the number of hours: ";
		cin >> no_of_hours;
	}
	void AddSal()
	{
		if (salary < 500)
			salary += 10;
	}
	void AddWork()
	{
		if (no_of_hours > 6)
			salary += 5;
	}
	void DisplaySalary()
	{
		cout << salary;
	}
};

int main()
{
	int num;
	cout << "Enter the number of employees: ";
	cin >> num;
	Employee* emp=new Employee[num];
	for (int i = 0; i < num ; i++)
	{
		emp[i].getinfo();
		emp[i].AddSal();
		emp[i].AddWork();
	}
	for (int i = 0; i < num; i++)
	{
		cout << "\nThe final salary of employee "<< i +1 <<" is:";
		emp[i].DisplaySalary();
	}
}
*/