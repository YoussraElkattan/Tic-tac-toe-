#include <iostream>
#include <string>
using namespace std;

class student {
public:
    string name;
    string phone_no;
    string address;
    int roll_no;
};

int main() {
    student no1;
    no1.name = "Sam";
    no1.phone_no = "123456789";
    no1.address = "Japan";
    no1.roll_no = 1;
    student no2;
    no2.name = "John";
    no2.phone_no = "987654321";
    no2.address = "Brazil";
    no2.roll_no = 2;

    cout << "Student 1" << endl;
    cout << "Name: " << no1.name << endl;
    cout << "roll: " << no1.roll_no << endl;
    cout << "Phone-no: : " << no1.phone_no << endl;
    cout << "Address: " << no1.address << endl;
    cout << "Student 2" << endl;
    cout << "roll: " << no2.roll_no << endl;
    cout << "Name: " << no2.name << endl;
    cout << "Phone-no: : " << no2.phone_no << endl;
    cout << "Address: " << no2.address << endl;
}