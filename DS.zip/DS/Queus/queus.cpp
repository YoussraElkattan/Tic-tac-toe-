#include <iostream>
using namespace std;

int arr[100] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
int size = 100;
int first = arr[0];
int counter = 14;
int rear = arr[counter-1];
bool isfull()
{
    if (counter == size)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool isEmpty()
{
    if (counter == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
void enqueue(int x)
{
    if (isfull())
    {
        cout << "queue is full";
    }
    else if (isEmpty())
    {
        first = x;
        counter++;
    }
    else
    {
        counter++;
        arr[counter] = x;
        
    }
}

void dequeue()
{
    if (isEmpty())
    {
        cout << "queue is empty nothing to delete";
    }
    else
    {
        cout << "element: "<<first<<" is dequeued";
        arr[0] = arr[1];
        for (int i = 1; i < size; i++)
        {
            arr[i] = arr[i + 1];
        }
        counter--;
    }
}
void displayQueue()
{
    for (int i = 0; i < size; i++)
    {
        cout << arr[i];
    }
    cout << "\nQueue load is: " << counter;
}

void showQueueElementPlace(int x)
{
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == x)
        {
            cout << "Element place is: " << i;
        }
    }
}

int main()
{
    dequeue();
    displayQueue();
    enqueue(3);


}