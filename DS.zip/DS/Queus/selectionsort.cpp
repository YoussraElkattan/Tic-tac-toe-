#include<iostream>
using namespace std;
void selectionSort(int arr[], int n)
{
    for (int i = n - 1;i >= 1; i--)
    {
        int max = i;
    for (int j = 0; j< i; j++) 
        if (arr[j] >= arr[max])
            max = j;
    swap(arr[i], arr[max]);
    }
    for (int k = 0; k < n; k++){
        cout<<arr[k];
    }
}

int main(){
    int arr[] = {2,1,6,4,3,7,5,};
    selectionSort(arr, 6);
    
}
