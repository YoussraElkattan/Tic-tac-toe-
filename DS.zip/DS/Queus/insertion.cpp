#include <iostream>
using namespace std;

void insertionSort(int arr[], int n)
{
    int j=n-1 , x;
    for (int i = 0; i < n; i++)
    {
        while( j > 0 && arr[j] < arr[j-1]){
            swap(arr[j], arr[j-1]);
            j--;
        }
    }
    for (int k = 0; k < n; k++)
        {
            cout << arr[k];
        }
}

    int main()
    {
        int arr[] = {
            2,
            1,
            6,
            4,
            3,
            7,
            5,
        };
        insertionSort(arr, 7);
    }
