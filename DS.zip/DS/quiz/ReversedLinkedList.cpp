#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node(int data, Node *next)
    {
        this->data = data;
        this->next = next;
    }
};

void append(Node **head, int data)
{
    Node *newNode = new Node(data, 0);
    Node *nodePtr;

    if (!*head)
        *head = newNode;
    else
    {
        nodePtr = *head;
        while (nodePtr->next)
        {
            nodePtr = nodePtr->next;
        }
        nodePtr->next = newNode;
    }
}

void print(Node *head)
{
    Node *nodePtr = head;
    while (nodePtr)
    {
        cout << nodePtr->data << (nodePtr->next ? " " : "");
        nodePtr = nodePtr->next;
    }
    cout << endl;
}

Node *ReverseList(Node *head)
{   
   
    Node *current = head;
    Node *prev = NULL;
    Node *next = NULL;
  
        while (current != NULL) {
            next = current->next;
            current->next = prev;
            prev = current;
            current = next;
        }
        head = prev;
}



int main()
{
    Node *head = 0;
    append(&head, 1);
    append(&head, 2);
    append(&head, 3);
    append(&head, 4);
    append(&head, 5);
    print(head);

    Node *head2 = ReverseList(head);
    print(head2);
}