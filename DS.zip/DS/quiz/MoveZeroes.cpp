#include<iostream>
using namespace std;

void MoveZeroes(int A[], int n) {
   int current = 0;
   int temp = 0;
   int previous = 0;
    for(int i = 0; i < n; i++ ){
      if(A[i] == 0){
        temp = A[i-1];
        A[i-1] = A[i];
        A[i] = temp;
      }
    }

}
int main() {

  int arr[] = {1,0,2,0,3,0,4,0,5,0};
  int n = sizeof(arr) / sizeof(arr[0]);

  cout << "Before: " <<endl;
  
  for(int i = 0 ; i < n; i++) {
    cout << arr[i];
    cout << ", ";
  }  
  
  MoveZeroes(arr, n);
  
  cout << endl<< "After: "<< endl;
  for(int i=0 ; i<n; i++) {
    cout << arr[i];
    cout << ", ";
  }  
} 