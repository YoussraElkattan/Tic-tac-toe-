#include<iostream>
using namespace std;

class Student{
    public:
    string name;
    string phone;
    string address;
    string roll_no;
};

int main(){
    Student first;
    first.name = "Sam";
    first.address = "somewhere on Earth";
    first.phone = "1234";
    first.roll_no = "1";

    Student second;
    second.name = "John";
    second.address = "nowhere";
    second.phone = "4321";
    second.roll_no = "2";

    cout<<first.name<<endl;
    cout<<first.phone<<endl;
    cout<<first.address<<endl;
    cout<<first.roll_no<<endl;

    cout<<second.name<<endl;
    cout<<second.phone<<endl;
    cout<<second.address<<endl;
    cout<<second.roll_no<<endl;

}