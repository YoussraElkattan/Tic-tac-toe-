#include<iostream>
using namespace std;

class Employee{
    public:
    int salary;
    int hours;
    void getInfo(){
        cout<<"Enter Salary\n";
        cin>> salary;
        cout<<"Enter Hours\n";
        cin>>hours;
        AddSal();
        AddWork();
    }
    void AddSal(){
        if(salary < 500){
            salary = salary + 10;
        }
    }

    void AddWork(){
        if(hours > 6){
            salary = salary + 5;
        }
    }
};

int main(){
    Employee first;
    first.getInfo();
    cout<< first.salary;
}