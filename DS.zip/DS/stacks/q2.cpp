#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node *link;
};

Node *top;
void push(int data)
{
    Node *temp = new Node();
    if (!temp)
    {
        cout << "Stack Overflow";
        exit(1);
    }
    temp->data = data;
    temp->link = top;
    top = temp;
}
int isEmpty()
{
    return top == NULL;
}
int peek()
{
    if (!isEmpty())
        return top->data;
    else
        exit(1);
}
void pop()
{
    Node *temp;
    if (top == NULL)
    {
        cout << "Stack Underflow" << endl;
        exit(1);
    }
    else
    {
        temp = top;
        top = top->link;
        free(temp);
    }
}
void display()
{
    Node *temp;
    if (top == NULL)
    {
        cout << "Stack Underflow";
        exit(1);
    }
    else
    {
        temp = top;
        cout<<"displaying stack\n";
        while (temp != NULL)
        {
            cout << temp->data << "\n";
            temp = temp->link;
        }
    }
}
int main()
{
    push(1);
    push(2);
    push(3);
    push(4);
    display();
    pop();
    pop();
    display();
    return 0;
}