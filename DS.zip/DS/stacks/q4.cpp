#include <iostream>
#include <string>
using namespace std;
#define SIZE 10

string arr[SIZE];
unsigned a = -1;

void push(char ch) {
    a = a + 1;
    arr[a] = ch;
}

void pop() {
    a = a - 1;
}

void display() {
    for (int j = a; j >= 0; j--)
        cout << arr[j];
}

int main() {
    string str;
    getline(cin, str);
        for (int i = 0; i < (str.length()); i++)
            push(str[i]);
        display();
}

//o(n)