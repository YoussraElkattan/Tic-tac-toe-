#include <iostream>
using namespace std;
int  n = 50, stack[50], top = -1;
void push(int val)
{
    if (top >= n - 1)
        cout << "Stack Overflow" << endl;
    else
    {
        top++;
        stack[top] = val;
    }
}
void pop()
{
    if (top <= -1)
        cout << "Stack Underflow" << endl;
    else
    {
        cout<< stack[top] << endl;
        top--;
    }
}
void display()
{
    if (top >= 0)
    {
        cout << "Displaying stack ";
        for (int i = top; i >= 0; i--)
            cout << stack[i] << " ";
        cout << endl;
    }
    else
        cout << "Stack is empty";
}
int main()
{
    int choice, val;
    cout << "1) Push in stack" << endl;
    cout << "2) Pop from stack" << endl;
    cout << "3) Display stack" << endl;
    cout << "4) Exit" << endl;
    while (choice != 4)
    {
        cout << "Enter choice: " << endl;
        cin >> choice;
        if(choice == 1){
            cout << "Enter value to be pushed:" << endl;
            cin >> val;
            push(val);
        }else if(choice == 2){
            cout << "Enter value to be poped:" << endl;
            pop();
        }else if(choice == 3){
            display();
        }else{
            cout << "Invalid choice" << endl;
        }
    }

    return 0;
}