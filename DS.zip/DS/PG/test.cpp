#include<bits/stdc++.h>
using namespace std;
stack<int> s;
int n;
void sortstack()
{
    if(s.size()==1)
    {
        return ;
    }
    int num1=s.top();
    s.pop();
    int num2=s.top();
    s.pop();
    s.push(max(num1,num2));
    sortstack();
    s.push(min(num1,num2));

}

int main()
{
    cin>>n;

    for(int i=0;i<n;i++)
    {
        int num;
        cin>>num;
        s.push(num);
    }
    
    for(int i=0;i<n;i++)
    {
          sortstack();
    }
    while(!s.empty())
    {
        cout<<s.top()<<" ";
        s.pop();
    }
    return 0;
}