#include <iostream>
using namespace std;

void selectionSort(int a[], int n)
{
    int minidx;
    for (int i = 0; i < n - 1; i++)
    {
        minidx = i;
        for (int j = i + 1; j < n; j++)
            if (a[j] < a[minidx])
                minidx = j;
        swap(a[i], a[minidx]);
    }
}

void display(int a[], int n){
    for(int i = 0; i < n; i++){
        cout<<a[i]<<endl;
    }
}

int main(){
    int array[6] = {22,33,44,11,10,9};
    selectionSort(array, 6);
    display(array, 6);
}