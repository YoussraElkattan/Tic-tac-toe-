class Person:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    def __str__(self):
        return f'({self.name}, {self.age})'

    def incrementAge(self, addAge):
        self.age = self.age + addAge


class Student(Person):
    def __init__(self, name, age, grade):
        super().__init__(name, age, grade)

nehalIbrahim = Student('Nehal', 11, 'batekh')
nehalIbrahim.incrementAge(10)

print(nehalIbrahim.age)
