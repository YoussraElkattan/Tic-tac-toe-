#include<iostream>
using namespace std;

void insertionSort(int arr[], int n){
    int k, j;
    for(int i = 1; i < n; i++){
        k = arr[i];
        j = i -1;

        while(j >= 0 && arr[j] > k){
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = k;
    }
}

void display(int arr[], int n){
    for (int i = 0; i < n ; i++){
        cout<<arr[i]<<endl;
    }
}

int main(){
    int array[] = {3,2,4,1,5,6,8,7,9};
    int n = sizeof(array) / sizeof(array[0]);
    insertionSort(array, n);
    display(array, n);
}