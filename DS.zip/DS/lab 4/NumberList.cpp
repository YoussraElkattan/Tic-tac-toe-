#include "NumberList.h"
#include <iostream>
using namespace std;

void NumberList::appendNode(double val)
{
  ListNode *newNode;
  ListNode *nodePtr;

  newNode = new ListNode;
  newNode->value = val;
  newNode->next = nullptr;
  if (!head)
    head = newNode;
  else
  {
    nodePtr = head;
    while (nodePtr->next)
      nodePtr = nodePtr->next;
    nodePtr->next = newNode;
  }
}

void NumberList::displayList() const
{
  ListNode *nodePtr;
  nodePtr = head;
  while (nodePtr)
  {
    cout << nodePtr->value << (nodePtr->next ? " " : "");
    nodePtr = nodePtr->next;
  }
}

void NumberList::insertNode(int pos, double val)
{ /*write this*/
ListNode *newNode;
  ListNode *prev;
  newNode->value = val;
  prev = head;

  for (int i = 2; i < pos; i++)
  {
    if (prev->next != NULL)
    {
      prev = prev->next;
    }
  }
  newNode->next = prev->next;
  prev->next = newNode;
}
NumberList::ListNode *NumberList::findNode(double val)
{ /*write this*/
ListNode *findPtr = head;

    while (findPtr->next != NULL)
    {
      if(findPtr->value == val){
        cout<< val<< " found at node " << &findPtr;
        break;
      }

    }
    return findPtr;
}
int NumberList::deleteNode(double val)
{ /*write this*/
ListNode *prev = head;
    ListNode *current = NULL;
    
    while(prev->next != NULL){
      if (prev->value == val){
        current = prev->next;
        prev->next = current->next;
      }
    }
    return val;
}
void NumberList::deleteList()
{ /*write this*/
ListNode *current = head;
    ListNode *next = NULL;

    while(current != NULL){
      next = current->next;
      delete current;
      current = next;
    }
}