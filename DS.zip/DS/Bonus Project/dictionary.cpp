#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
using namespace std;
using std::fill;
class Dictionary
{
public:
    string path;
    int word = 0;
    Dictionary(string file)
    {
        path = file;
    }
//iterate through the file and with every space or newline counts new word
    int size()
    {
        ifstream file(path);
        word = 0;
        char ch;
        file.seekg(0, ios::beg);

        while (file)
        {
            file.get(ch);
            if (ch == ' ' || ch == '\n')
                word++;
        }
        cout << "Words=" << word << "\n";
        file.close();
        return word;
    }
//iterating through words to find a match
    int lookup(string word)
    {
        ifstream file;
        size_t pos;
        string line;

        file.open(path);

        while (getline(file, line))
        {
            pos = line.find(word);
            if (pos != string::npos)
            {
                cout << "found!\n";
                return 1;
            }
            else
            {
                cout << "Not found!\n";
                return 0;
            }
        }
    }
//looking for the word if found return error if not insert it
    int insert(string word)
    {
        ifstream file;
        size_t pos;
        string line;

        file.open(path);

        while (getline(file, line))
        {
            pos = line.find(word);
            if (pos != string::npos)
            {
                cout << "Error: word inserted before!\n";
                return 0;
            }
            else
            {
                ofstream file;
                file.open(path, ios::app);
                file << " " + word;
                return 0;
            }
        }
    }
    //appending words to one string then remove the word then overwriting the words again
    int removeWord(string value)
    {

        ifstream file(path);
        string wordString;
        string words;
        for (int i = 0; i < word; i++)
        {
            file >> words;
            wordString = wordString + " " + words;
        }
        size_t valPosition = wordString.find(value);

        if (valPosition != string::npos)
        {
            int valueLength = value.size();
            wordString.erase(valPosition - 1, valueLength + 1);
            ofstream upFile;
            upFile.open(path);
            upFile << wordString;
        }
        else
        {
            cout<<"Error: Requested word not found to be removed";
        }

        return 1;
    }
};

int main()
{
    Dictionary dct = Dictionary("test.txt");
    dct.size();
    dct.lookup("ali");
    dct.insert("ali");
    dct.lookup("ali");
    dct.size();
    dct.removeWord("ali");
}