#include<iostream>
using namespace std;

Node* checkSorted(Node* head ){
    Node
}