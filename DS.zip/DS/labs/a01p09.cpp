#include<iostream>
using namespace std;

int main(){
    int arr[] = {1,2,3,4,5,6,7};
    int size = sizeof(arr)/sizeof(arr[0]);
    for (int i = 0; i < size; i++) 
    { 
        int count = 0; 
        for (int j = 0; j < size; j++) 
            if (arr[j] > arr[i]) 
                count++; 
  
        if (count >= 2) 
            cout << arr[i] << " "; 
    } 
}