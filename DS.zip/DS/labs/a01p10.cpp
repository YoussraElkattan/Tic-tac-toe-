#include<iostream>
using namespace std;

int main(){
int arr[] = {1,2,3,4,5,6,7,8};
int size = sizeof(arr)/sizeof(arr[0]);
int max_count = 0;

for (int i = 0; i < 5; i++)
{
   int count = 1;
   for (int j = i + 1; j < 5; j++)
       if (arr[i] == arr[j])
           count++;
   if (count > max_count)
      max_count = count;
}

for (int i = 0;i < 5; i++)
{
   int count = 1;
   for (int j = i + 1; j < 5; j++)
       if (arr[i] == arr[j])
           count++;
   if (count == max_count)
       cout << arr[i] << endl;
}
}