#include<iostream>
using namespace std;

int main(){
    int a1[] = {1,2,4,3};
    int largestNumber = 0;
    for(int i = 0;i < 3; i++){
        if(largestNumber < a1[i]){
            largestNumber = a1[i];
        }
    }
    cout<< largestNumber;
}