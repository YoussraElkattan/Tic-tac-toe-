#include<iostream>
using namespace std;

int main(){
    int arr[] = {0,1,2,0,1,2,0,1,2};
    int size = sizeof(arr)/sizeof(arr[0]);
    int zero = 0;
    int one = 0;

        for (int i = 0; i < size; i++) {      
              if (arr[i] == 0)
                  zero++;  
              if (arr[i] == 1)
                   one++;
        }
        for (int i = 0; i < zero; i++) {
            arr[i] = 0;
        }
       for (int i = zero; i < (zero + one); i++) {
            arr[i] = 1;
       }
      for (int i = (zero + one); i < size; i++) {
            arr[i] = 2;
   for (int i=0; i< size; i++){ 
      cout << arr[i] << " ";
      }
}