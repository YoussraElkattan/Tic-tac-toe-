#include<iostream>
using namespace std;

int main(){
    int arr[] = {1,2,4,5,6,7};
    int size = sizeof(arr)/sizeof(arr[0]);
    
    for(int i = 0; i < size; i++){

        if(arr[i] % 2 == 0){

            cout << arr[i] <<" ";
        }
    }
    for(int i = 0; i <= size; i++){
        if (arr[i] %2 == 1){

            cout << arr[i] <<" ";
        }
    }

}