#include<iostream>
using namespace std;



int countLetter(char letter, string str){
    int count = 0;
    for(int i = 0; i < str.length();i++ ){
        if(letter == str[i]){
            count +=1;
        }
    }
    return count;
};
int main(){
 string str  = "lollipop";
 char letter = 'l';
 cout << countLetter(letter, str);
};


