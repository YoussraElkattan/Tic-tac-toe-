#include<iostream>
using namespace std;

int main(){
    int arr[] = {1,2,3,4,5,6};
    int size = sizeof(arr)/sizeof(arr[0]);
    int previous = arr[0]; 
    arr[0] = arr[0] * arr[1]; 
  
    for (int i = 1; i < size - 1; i++){
        int current = arr[i]; 
        arr[i] = previous * arr[i + 1]; 
        previous = current;
    }
    arr[size-1] = previous * arr[size-1]; 
    for (int i=0; i< size; i++){ 
      cout << arr[i] << " ";
      }
}