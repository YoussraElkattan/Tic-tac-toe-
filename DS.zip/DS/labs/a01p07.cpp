#include<iostream>
#include<cstdlib>
using namespace std;

int main() {
   int a1[] = {0,1,2,3,4,5};
   int max =0;
   int max2 =0;
   for(int j = 0;j < 6; j++){
      if (a1[j] > max){
         max2 = max;
         max = a1[j];
      }
      else if (a1[j] > max2 ){
         max2 = a1[j];
      }
    }
    cout <<max2;
}