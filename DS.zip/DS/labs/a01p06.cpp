#include<iostream>
using namespace std;

int main(){
    int a1[] = {43,54,67,89};
    int max =0;
    int max2 =0;
    int max3 =0;
    for(int i = 0;i < 4; i++){
        if (a1[i] > max){
         max3 = max2;
         max2 = max;
         max = a1[i];
      }
      else if (a1[i] > max2 ){
         max3 = max2;
         max2 = a1[i];
      }
      else if (a1[i] > max3){
         max3 = a1[i];
      }
    }
    cout<< "1st: "<<max <<" "<< "2nd: " <<max2<< " "<< "3rd: " << max3;
}