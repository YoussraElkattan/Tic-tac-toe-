#include<iostream>
using namespace std;

float dotProduct(float v1[3], float v2[3]){
    float product = 0;
    for(int i = 0; i < 3; i++){
        product = product +(v1[i]*v2[i]);
    }
    return product;
}

int main(){
    float v1[] =  {4, 3.1, 2};
    float v2[] = {5, 1, 3};
    cout<< dotProduct(v1, v2);
}