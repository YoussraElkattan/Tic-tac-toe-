#include<iostream>
using namespace std;

int main(){
    int arr[] = {1,3,4,6,6,5,5,3,4};
    int size = sizeof(arr)/sizeof(arr[0]);
    int times = arr[0];
    for (int i = 1; i < size; i++){
        times = times ^ arr[i];
    }
    cout << times;
}