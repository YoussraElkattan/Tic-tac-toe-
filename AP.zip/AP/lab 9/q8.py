points = [ (2,3), (4,4), (1,2), (5,6), (7,8) ] 
print(max(map(lambda x: x[0], points))) 

