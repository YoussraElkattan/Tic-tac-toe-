lst = [70, 60, 50, 30, 40]
print(list(map(lambda x: (x-32)*(5/9), lst)))