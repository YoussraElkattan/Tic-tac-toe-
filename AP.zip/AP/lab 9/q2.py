odd_pairs= [(x, y) for x in range(1, 10) for y in range(1, 11) if(x<y) and x%2 != 0 and y%2 != 0]

print (odd_pairs)