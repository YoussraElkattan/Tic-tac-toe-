lst1= []
lst2= []
def evenOdd(lst):
    for x in lst:
        if x%2 == 0:
            lst1.append(x)
        else:
            lst2.append(x) 
    return lst1 + lst2        
print(evenOdd([1,2,3,4,5,6,7,8,9]))

