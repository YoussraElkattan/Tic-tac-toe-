odd_pairs= sum([x*x for x in range(1, 10) if x%2 != 0], 1)

print (odd_pairs)