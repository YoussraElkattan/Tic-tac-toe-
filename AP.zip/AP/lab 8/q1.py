class Calculator():
    def add(self, x, y):
        ret = x+y
        return ret
    def sub(self, x, y):
        ret = x-y
        return ret
    def mul(self, x, y):
        ret = x * y
        return ret
    def div(self, x, y):
        ret = x / y
        return ret
