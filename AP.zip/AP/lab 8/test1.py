from q1 import Calculator
import unittest
c = Calculator()
class testing(unittest.TestCase):
    def test_add(self):
        self.assertEqual(c.add(1,2), 3)
    def test_sub(self):
        self.assertEqual(c.sub(3,2), 1)    
    def test_mul(self):
        self.assertEqual(c.mul(2,3), 6)    
    def test_div(self):
        self.assertEqual(c.div(6,2), 2)    
        
unittest.main()        