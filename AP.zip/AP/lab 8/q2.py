import unittest

def factorial(x):
    fact = 1
    if x == 0:
        return 1
    else:
        for i in range(1,x+1):
            fact = fact * i
        return fact

class TestFactorial(unittest.TestCase):
    def test_zero_factorial_is_one(self):
        self.assertEqual(factorial(0), 1)
    def test_one_factorial_is_one(self):
        self.assertEqual(factorial(1), 1)
    def test_five_factorial_is_120(self):
        self.assertEqual(factorial(5), 120)

if __name__ == "__main__":
    unittest.main()