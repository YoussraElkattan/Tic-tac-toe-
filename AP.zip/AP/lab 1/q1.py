
from unittest import result


a = 2
b = 3
def add_times(a, b):
    return a*b, a + b
add_times(a, b)

