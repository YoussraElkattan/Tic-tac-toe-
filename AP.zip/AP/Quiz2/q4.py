import math
class rational():
    def __init__(self, p, q):
        g =  math.gcd(p, q)
        self.num = p/g  
        self.den = q/g
        
    def __str__(self):
        return f"{self.num}/{self.den}"
    
p = rational(10, 12)
print(p)
q = rational(6, 9)    
print(q)  
p+q      

    