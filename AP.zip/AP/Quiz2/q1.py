import unittest

def contains_character(password: str, target: str) -> bool:
    has_char = False
    for char in password:
        if char in target:
            has_char = True
            break
    return has_char

def is_valid_size(password: str) -> bool:
    MIN_SIZE = 6
    MAX_SIZE = 20
    password_size = len(password)
    return MIN_SIZE <= password_size <= MAX_SIZE

class TestPass(unittest.TestCase):
    def test_contains_characters(self):
        self.assertEqual(contains_character("abcd", "d"), True)
        
    def test_is_valid_size(self):
        self.assertEqual(is_valid_size("12345678"), True)    
        
       
unittest.main()        