class Dog:
    def walk(self):
        return "*walking*"
    def speak(self):
        return "Woof!"
class JackRussellTerrier(Dog):
    def talk(self):
        return super().speak()
bobo = JackRussellTerrier()
bobo.talk()

#Woof!
# because class JackRussellTerrier inhirates from class Dog and in method talk it inherited the method talk from class Dog