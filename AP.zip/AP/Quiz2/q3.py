class A:
    def f(self):    
        return self.g()
    def g(self):
        return 'A'
class B(A):
    def g(self):
        return 'B'
a = A()
b = B()
print (a.f(), b.f())
print (a.g(), b.g())

#A B 
#A B

#in first print class A method f returns method g and method g returns letter "A" and in class B inherites from
#class A so when calling b.f() it returns b.g() and b.g is overrided to return letter "B"
#in second print class A method g returns "A" so it prints the return value of the method and in class B method g is overrided so returns "B"