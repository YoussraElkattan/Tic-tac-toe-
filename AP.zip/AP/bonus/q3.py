class Ticket:
    def __init__(self, cost, time):
        self.cost = cost
        self.time = time
        
    def __str__(self):
            return f'({self.cost},{self.time})'
        
    def is_evening_time(self):
        if self.time in range(18,24 ):
                print("True")
                return True
        else:
            print("False")
            return False
        
    def bulk_discount(self, n):
                if n in range(4, 9):
                    discount = 10
                    discount_amount = (self.cost*discount) / 100
                    self.cost = self.cost - discount_amount
                elif n > 10 :
                    discount = 20
                    discount_amount = (self.cost*discount) / 100
                    self.cost = self.cost - discount_amount
test = Ticket(100, 12)
test2 = Ticket(120, 19)

test.is_evening_time()
test2.is_evening_time()
                        
test.bulk_discount(5)      
test2.bulk_discount(12)
print(test)                  
print(test2)

                    