import doctest
import re
def digits_only(string):

    
    """
    >>> digits_only("abc123")
    '123'
    >>> digits_only("a1b2c4")
    '124'
    """
    list = re.findall(r'\d+', string)
    return "".join(list)
    
    
            
doctest.testmod(verbose=True) 