from audioop import add
import unittest
def Add(arg):
    total = 0
    for val in arg:
        total += val
    return total
class TestSum(unittest.TestCase):
    def test_list_int(self):
        

        """
        Test that it can sum a list of integers
        """
        self.assertEqual(Add([1, 2, 3]),6)
    def test_list_fraction(self):
        self.assertEqual(Add([1.2, 1.5, 1.6]),4.300000000000001)
        """
        Test that it can sum a list of fractions
        """
    def test_bad_type(self):
        self.assertRaises(TypeError, Add,['a','b'])
        """
        Test that it can handle bad input
        """
unittest.main()