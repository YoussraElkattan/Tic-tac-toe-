from q3 import Ticket

class MovieTicket(Ticket):
    def __init__(self, movie_name,  cost, time):
        super().__init__(cost, time)
        self.movieName = movie_name
        
    def __str__(self):
            return f'({self.cost},{self.time}, {self.movieName})'
        
    def afternoon_discount(self):
            if self.time in range(12, 18):
                discount = 10
                discount_amount = (self.cost*10) / 100
                self.cost = self.cost - discount_amount


test = MovieTicket('avengers', 100, 15)
test.afternoon_discount()
print(test)            