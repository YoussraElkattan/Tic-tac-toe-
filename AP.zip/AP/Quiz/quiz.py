class Person:
    def __init__(self, firstName, ){
        
    }