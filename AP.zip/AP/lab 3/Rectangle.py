import math


class rectangle:
    def __init__(self, height = 1, width = 2):
        self.height = height
        self.width = width

    def get_area(self):
        return self.width * self.height      

    def get_perimeter(self):
        return 2*(self.height + self.width)  
