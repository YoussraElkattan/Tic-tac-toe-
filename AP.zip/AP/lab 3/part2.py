
from Rectangle import rectangle

def main():
    rectangle1 = rectangle(4, 40)
    print(f"rectangle {rectangle1.height} , {rectangle1.width}, {rectangle1.get_perimeter()}, {rectangle1.get_area()}")

    rectangle2 = rectangle(3.5, 35.7)
    print(f"rectangle {rectangle2.height}, {rectangle2.width} , {rectangle2.get_perimeter()}, {rectangle2.get_area()}  ")

main()