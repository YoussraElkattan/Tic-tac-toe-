class Address:
    def __init__(self, street, city):
        self.street = str(street)
        self.city = str(city)
    def show(self):
        print(self.street)
        print(self.city)
         
class Person:
    def __init__(self, name, email):
        self.name = str(name)
        self.email= str(email)
    def show(self):
        print(self.name + ' ' + self.email)
        
class Contact(Person, Address):
    def __init__(self, street, city, name, email):
        Address.__init__(self, street, city)
        Person.__init__(self, name, email)
        
    
    def show(self):
        Person.show(self)
        Address.show(self)

x = Contact("abo qir", "borg-elarab", "ali", "ali.nemir@ejust.edu.eg")
x.show()