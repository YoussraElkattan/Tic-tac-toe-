# 1-
class Shape(object):
    def __init__(self):
        pass

    def area(self):
        return 0

class Square(Shape):
    def __init__(self, length = 0):
        Shape.__init__(self)
        self.length = length

    def area(self):
        return self.length*self.length

Areasqr = Square(6)
print(Areasqr.area())     

print(Square().area()) 

#2- 

class Rectangle():
    def __init__(self,l,w):
        self.length = l
        self.width = w

    def area(self):
        return self.length*self.width


rectangle = Rectangle(2,4)
print(rectangle.area())