# 1-spell is the parent and Accio and Confundo and study spell are the childs
# 2- Accio
#summing charm
# No description
# confundus charm confundo
# causes the victim to become confused
# 3- the method in the Confundo because this the override as it has the priority
# 4- Adding these lines to class Accio
# def get_description(self):
#       return "This charm summons an object to caster, potentially over a significant distance"    
