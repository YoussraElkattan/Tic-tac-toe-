from tokenize import Number


def add(x, y):
    try:
        if type(x) == list and type(y) == list:
            list( map(add, x, y) )
        elif type(x) == int and type(y) == list:    
                [x+i for i in y]
    except:
        print("expection occured")
        
        
add(1,[1,2,3])        