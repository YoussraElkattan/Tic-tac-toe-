from math import remainder

number = int(input("Please Enter a Number: "))

def reverse(number):
    count = 0
    x = int(len(str(number)))
    for i in range(len(str(number))):
        
        remainder = number % 10
        number = number // 10
        count = count + (remainder*(10**(x-(i+1))))
    print(count)
    return  count
def isPalindrome(number):
    
    if reverse(number) == number:
        print('Number is same')
    else:
        print("not same")  

isPalindrome(number)       