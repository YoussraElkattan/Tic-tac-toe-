n1 = int(input("Please Enter n1: "))
n2 = int(input("Please Enter n2: "))
n3 = int(input("Please Enter n3: "))
def displaySortedNumber(n1, n2, n3):
    numbers = [n1, n2, n3]
    numbers.sort(reverse= True)
    print (numbers)
        
      

displaySortedNumber(n1, n2, n3)      
        