list = [1, 2, 3, 4, 5]

def print_list_element(thelist, index):
    print(thelist[index])


try :
    print_list_element(list, 2)
except IndexError:
    print('out of index ', IndexError)

try :
    print_list_element(list, 6)
except IndexError:
    print('out of index ', IndexError)
