def divide(x,y):
    """
    >>> divide(6,2)
    3.0
    >>> divide(6,1)
    6.0
    >>> divide(6,3)
    2.0
    """
    return x/y


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)