import unittest
class Warehouse:
    def __init__(self, free_space = 20):
        self.packages_ID = []
        self.packages_size = []
        self.free_space = free_space
    def add_to_stock(self, ID, size):
        self.packages_ID.append(ID)
        self.packages_size.append(size)
        self.free_space -= size
    def remove_from_stock(self):
        self.free_space = self.free_space +self.packages_size[0]
        self.packages_ID.pop(0)
        self.packages_size.pop(0)
        
class TestWarehouse(unittest.TestCase):
    def setUp(self):
        self.warehouse = Warehouse()
    def test_add(self):
        self.warehouse.add_to_stock("1", 2)
        self.assertEqual(self.warehouse.free_space, 18)
    def test_remove(self):
        
        with self.assertRaises(Exception):
            self.warehouse.remove_from_stock()
    def test_free_space(self):
        self.warehouse.add_to_stock("IV", 12)
        self.warehouse.add_to_stock("V", 10)
        self.assertEqual(self.warehouse.free_space, 8)
unittest.main()