print([i for i in range(4, 30) if i%5 == 0 and i >= 10])
print(list(filter(lambda x: x%5 == 0 and x >=10, range(4,30))))
def sort(x): 
    if x%5 == 0 and x>= 10:
        return x
print(list(filter(sort, range(4,30))))
