import logging
class Logger(object):

    """A file-based message logger with the following properties
    Attributes:
    file_name: a string representing the full path of the log file to which
    this logger will write its messages
    """

    def _init_(self, file_name):
        """Return a Logger object whose file_name is file_name"""

        self.file_name = file_name

    def _write_log(self, level, msg):
        """Writes a message to the file_name for a specific Logger instance"""

        with open(self.file_name, 'a') as log_file:
            log_file.write('[{0}] {1}\n'.format(level, msg))

    def __Critical(self, msg):
        Logger._write_log("Critical" ,msg )
        
    def __Error(self, msg):
        Logger._write_log("Error" ,msg)
        
    def __Warning(self, msg):
        Logger._write_log("Warning" ,msg) 


    def __Info(self, msg):
        Logger._write_log("Info" ,msg) 

    def __Debug(self, msg):
        Logger._write_log("Debug" ,msg)