import math

print(math.factorial(5))