class SingletonObject(object):
    class __SingletonObject():
        def _init_(self):
            self.val = None

        def _str_(self):
            return "{0!r} {1}".format(self, self.val)
        
    instance = None  
    def _new_(cls):
        
        if(SingletonObject.instance == None):
            SingletonObject.instance = SingletonObject.__SingletonObject()
        return SingletonObject.instance

    def _getattr_(self, name):
        return getattr(self.instance, name)

    def _setattr_(self, name):
        return setattr
